<form class="form-inline">
    <div class="form-group">
      <label class="col-md-1 control-label" for="lunchBegins">Lunch (Begins search):</label>
    </div>
    <div class="form-group">
      <select class="selectpicker form-control" data-live-search="true" data-live-search-style="begins" title="Please select a lunch ...">
        <option>Hot Dog, Fries and a Soda</option>
        <option>Burger, Shake and a Smile</option>
        <option>Sugar, Spice and all things nice</option>
        <option>Baby Back Ribs</option>
        <option>A really really long option made to illustrate an issue with the live search in an inline form</option>
      </select>
    </div>
  </form>
  
  <form class="form-inline">
    <div class="form-group">
      <label class="col-md-1 control-label" for="lunchBegins">Lunch (Begins search):</label>
    </div>
    <div class="form-group">
      <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Please select a lunch ...">
        <option>Hot Dog, Fries and a Soda</option>
        <option>Burger, Shake and a Smile</option>
        <option>Sugar, Spice and all things nice</option>
        <option>Baby Back Ribs</option>
        <option>A really really long option made to illustrate an issue with the live search in an inline form</option>
      </select>
    </div>
  </form>
  
  <form class="form-inline">
    <div class="form-group">
      <label class="col-md-1 control-label" for="lunchBegins">Lunch (Begins search):</label>
    </div>
    <div class="form-group">
      <select class="selectpicker" data-live-search="true" data-live-search-style="begins" title="Please select a lunch ...">
        <option>Hot Dog, Fries and a Soda</option>
        <option>Burger, Shake and a Smile</option>
        <option>Sugar, Spice and all things nice</option>
        <option>Baby Back Ribs</option>
        <option>A really really long option made to illustrate an issue with the live search in an inline form</option>
      </select>
    </div>
  </form>