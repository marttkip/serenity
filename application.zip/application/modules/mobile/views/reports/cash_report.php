<!-- search -->
<?php echo $this->load->view('search/cash', '', TRUE);?>
<!-- end search -->
<?php echo $this->load->view('cash_statistics', '', TRUE);?>
 