<!-- search -->
<?php echo $this->load->view('search/debtors_report', '', TRUE);?>
<!-- end search -->
<?php echo $this->load->view('debt_statistics', '', TRUE);?>
