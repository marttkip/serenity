
<div class="row">
	<div class="col-md-12">
        <section class="panel panel-featured panel-featured-info">
            <header class="panel-heading">
                <h2 class="panel-title">Vitals</h2>
            </header>
            <div class="panel-body">
                <!-- vitals from java script -->
                <div id="vitals"></div>
                <!-- end of vitals data -->
            </div>
         </section>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <section class="panel panel-featured panel-featured-info">
			<header class="panel-heading">
				<h2 class="panel-title">Visit vitals</h2>
			</header>
			<div class="panel-body">
				<div id="previous_vitals"></div>
			</div>
		</section>
    </div>
</div>



